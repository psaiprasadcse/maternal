@echo off
python -m pip install -r requirements.txt
python run_all.py
pause
