"""Reproduce W1 ablations, shared five-fold CV, paired bootstrap, and figures.

Run from the folder containing this script and maternal_dataset_csv.csv.
A complete run may take several minutes depending on CPU.
"""
import subprocess,sys,pathlib
P=pathlib.Path(__file__).resolve().parent
for script in ["maternal_revision_audit.py", "paired_bootstrap_reference.py", "maternal_supplemental_figures.py", "cohort_selection_profile.py"]:
    print("Running",script,flush=True)
    subprocess.run([sys.executable,str(P/script)],check=True,cwd=P)
print("Finished. Outputs: Maternal_Revision_Audit_Results")
