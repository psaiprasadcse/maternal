import os,sys,importlib.util
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import pandas as pd,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import average_precision_score,roc_auc_score,confusion_matrix, brier_score_loss
from sklearn.linear_model import LogisticRegression
from pathlib import Path
R=Path(__file__).resolve().parent;OUT=R/'Maternal_Revision_Audit_Results'
S=importlib.util.spec_from_file_location('reviewpipe',R/'_maternal_pipeline_extracted.py');m=importlib.util.module_from_spec(S);sys.modules[S.name]=m;S.loader.exec_module(m)
df=m.clean_target(m.load_dataset(str(R/'maternal_dataset_csv.csv')))
sp=m.build_window_specs(df,3,'window_specific',['W1']);cols=list(dict.fromkeys(sp['W1'].all_feature_columns));z=df[cols+['risk']]
tr,va,te=m.split_dataframe(z,.70,.15,.15)
b=m.MaternalFeatureBuilder(max_missing_rate=.98,max_cardinality=30); Xtr=b.fit_transform(tr[cols]);Xva=b.transform(va[cols]);Xte=b.transform(te[cols]);pp=m.build_preprocessor(Xtr);a=pp.fit_transform(Xtr);bb=pp.transform(Xva);cc=pp.transform(Xte)
clf=m.get_models(['random_forest'])['RandomForest'];clf.fit(a,tr.risk);p=clf.predict_proba(cc)[:,1];y=te.risk.to_numpy();
print('W1 test auroc',roc_auc_score(y,p),'auprc',average_precision_score(y,p),flush=True)
# grouped permutation on encoded predictor families, same shuffled records across family members
names=m.get_feature_names(pp)
patterns={'Hemoglobin / anaemia':['hemoglobin','haemoglobin','anemia','anaemia'],'Blood pressure / hypertension':['blood_pressure','hypertension'],'Anthropometry':['bmi','weight','height'],'Pregnancy history':['pregnancy','prior','parity','delivery','miscarriage','no_pregnancy'],'Gestational dates':['gestat','duration','date','week'],'Glucose / urine':['glucose','sugar','urine','protein']}
arr=cc.toarray() if hasattr(cc,'toarray') else np.asarray(cc)
base=average_precision_score(y,p);rng=np.random.default_rng(42);row=[]
for group,tokens in patterns.items():
 ind=[i for i,n in enumerate(names) if any(t in n.lower() for t in tokens)]
 if not ind:continue
 v=[]
 for rep in range(5):
  perm=rng.permutation(len(y));tmp=arr.copy();tmp[:,ind]=arr[perm][:,ind];pred=clf.predict_proba(tmp)[:,1];v.append(base-average_precision_score(y,pred))
 row.append(dict(group=group,encoded_columns=len(ind),mean_delta_auprc=np.mean(v),sd_delta_auprc=np.std(v,ddof=1),n_repeats=5))
print('permutation rows',row,flush=True)
pd.DataFrame(row).to_csv(OUT/'09_W1_grouped_permutation_importance.csv',index=False)
a0=pd.DataFrame(row).sort_values('mean_delta_auprc');fig,ax=plt.subplots(figsize=(9,4.5));ax.barh(a0.group,a0.mean_delta_auprc,xerr=a0.sd_delta_auprc);ax.set_xlabel('Reduction in test AUPRC after permutation (larger = more important)');ax.set_title('W1 Random Forest – exploratory grouped permutation importance');ax.axvline(0,linestyle='--',linewidth=1);fig.tight_layout();fig.savefig(OUT/'W1_grouped_permutation_importance.png',dpi=170);plt.close(fig)
# calibration slope, intercept & plots (descriptive test-set diagnostics)
q=np.clip(p,1e-5,1-1e-5);logit=np.log(q/(1-q)).reshape(-1,1)
logitmodel=LogisticRegression(C=1e6,solver='lbfgs',max_iter=2000).fit(logit,y)
calib=dict(n=len(y),slope=float(logitmodel.coef_[0][0]),intercept=float(logitmodel.intercept_[0]),brier=float(brier_score_loss(y,p)),mean_pred=float(p.mean()),observed_rate=float(y.mean()))
pd.DataFrame([calib]).to_csv(OUT/'10_W1_calibration_diagnostics.csv',index=False)
from sklearn.calibration import calibration_curve
obs,mean=calibration_curve(y,p,n_bins=10,strategy='quantile');fig,ax=plt.subplots(figsize=(6,5));ax.plot([0,1],[0,1],'--',label='Ideal');ax.plot(mean,obs,'o-',label='W1 RF');ax.set(xlabel='Mean predicted probability',ylabel='Observed high-risk fraction',title='W1 hold-out calibration curve');ax.legend();fig.tight_layout();fig.savefig(OUT/'W1_calibration_diagnostic.png',dpi=170);plt.close(fig)
# decision-curve analysis (descriptive threshold-utility illustration; thresholds clinically unvalidated)
ts=np.linspace(.05,.95,91);prev=y.mean();dca=[]
for t in ts:
 pred=p>=t;tp=np.sum((y==1)&pred);fp=np.sum((y==0)&pred)
 dca.append(dict(threshold=t,net_benefit_model=tp/len(y)-fp/len(y)*t/(1-t),net_benefit_treat_all=prev-(1-prev)*t/(1-t),net_benefit_treat_none=0))
pd.DataFrame(dca).to_csv(OUT/'11_W1_exploratory_decision_curve.csv',index=False)
z=pd.DataFrame(dca);fig,ax=plt.subplots(figsize=(7,5));ax.plot(z.threshold,z.net_benefit_model,label='W1 Random Forest');ax.plot(z.threshold,z.net_benefit_treat_all,'--',label='Treat all');ax.plot(z.threshold,z.net_benefit_treat_none,':',label='Treat none');ax.set(xlabel='Risk decision threshold',ylabel='Net benefit per person',title='Exploratory decision curve (not clinical utility validation)');ax.set_ylim(-.2,.7);ax.legend();fig.tight_layout();fig.savefig(OUT/'W1_exploratory_decision_curve.png',dpi=170);plt.close(fig)
# windows and prevalence figure
v=pd.read_csv(OUT/'01_window_cohort_profile.csv');fig,ax=plt.subplots(figsize=(7.3,4));ax.bar(v.window,v.high_prevalence*100);ax.set(xlabel='Cumulative visit window',ylabel='High-risk prevalence (%)',title='Cohort selection changes class prevalence');ax.set_ylim(0,70)
for i,r in v.iterrows():ax.text(i,r.high_prevalence*100+1,f'{r.high_prevalence*100:.1f}%\nn={int(r.n)}',ha='center',fontsize=8)
fig.tight_layout();fig.savefig(OUT/'window_prevalence_and_count.png',dpi=170);plt.close(fig)
cv=pd.read_csv(OUT/'06_matched_cohort_cv_summary.csv');fig,ax=plt.subplots(figsize=(7.3,4.3));x=np.arange(len(cv));ax.errorbar(x,cv.auroc_mean,yerr=cv.auroc_sd,marker='o',capsize=4,label='AUROC');ax.errorbar(x,cv.auprc_mean,yerr=cv.auprc_sd,marker='s',capsize=4,label='AUPRC');ax.set_xticks(x,cv.window);ax.set(ylim=(.55,1.02),xlabel='Window; same 3,021 subjects in every window',ylabel='Mean ± SD across 5 folds',title='Matched-cohort Random Forest cross-validation');ax.legend();fig.tight_layout();fig.savefig(OUT/'matched_cohort_fivefold_performance.png',dpi=170);plt.close(fig)
# W0 threshold confusions
import json
with open(R/'Maternal_W0_threshold_audit.json') as f: data=json.load(f)
r=next(k for k in data if k['model']=='ExtraTrees');fig,axs=plt.subplots(1,2,figsize=(8.8,4));
for ax,t,txt in zip(axs,[r['threshold_f2opt'],.5],['Validation F2 threshold','Conventional threshold']):
 cm=np.array(r[f'cm_at_{t:.4f}']).reshape(2,2);im=ax.imshow(cm,cmap='Blues');ax.set_title(f'{txt}\nthreshold={t:.4f}');ax.set_xticks([0,1],['Pred low','Pred high']);ax.set_yticks([0,1],['Actual low','Actual high']);
 for i in range(2):
  for j in range(2):ax.text(j,i,str(cm[i,j]),ha='center',va='center',fontsize=14)
fig.suptitle('W0 Extra Trees: threshold materially changes the confusion matrix');fig.tight_layout();fig.savefig(OUT/'W0_threshold_sensitivity.png',dpi=170);plt.close(fig)
print('CALIB',calib,flush=True)
