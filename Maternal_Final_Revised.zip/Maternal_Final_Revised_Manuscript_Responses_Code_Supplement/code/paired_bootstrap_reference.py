import pandas as pd,numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score,brier_score_loss
from pathlib import Path
O=Path(__file__).resolve().parent/'Maternal_Revision_Audit_Results'
d=pd.read_csv(O/'05_matched_cohort_oof_predictions.csv')
wins=['W0','W1','W2','W3','W4']
a={w:d.query('window==@w').sort_values('sn').reset_index(drop=True) for w in wins}
y=a['W0'].risk.to_numpy()
for w in wins: assert (a[w].sn.to_numpy()==a['W0'].sn.to_numpy()).all() and (a[w].risk.to_numpy()==y).all()
N=len(y);rng=np.random.default_rng(20261015);B=600
rs=[]
for i in range(4):
 w1,w2=wins[i:i+2];p1=a[w1].prob.to_numpy();p2=a[w2].prob.to_numpy();
 dauc=[];dpr=[];dbri=[]
 for b in range(B):
  ix=rng.integers(0,N,N); yy=y[ix]
  if len(np.unique(yy))<2:continue
  dauc.append(roc_auc_score(yy,p2[ix])-roc_auc_score(yy,p1[ix]))
  dpr.append(average_precision_score(yy,p2[ix])-average_precision_score(yy,p1[ix]))
  dbri.append(brier_score_loss(yy,p2[ix])-brier_score_loss(yy,p1[ix]))
 for name,arr in [('AUROC',dauc),('AUPRC',dpr),('Brier',dbri)]:
  arr=np.asarray(arr)
  obs=({'AUROC':roc_auc_score,'AUPRC':average_precision_score,'Brier':brier_score_loss}[name])(y,p2)-({'AUROC':roc_auc_score,'AUPRC':average_precision_score,'Brier':brier_score_loss}[name])(y,p1)
  r=dict(from_window=w1,to_window=w2,metric=name,n=N,observed_difference=obs,CI95_low=np.quantile(arr,.025),CI95_high=np.quantile(arr,.975),bootstrap_sign_based_p=min(1,2*min(np.mean(arr<=0),np.mean(arr>=0))),resamples=len(arr))
  rs.append(r)
  print(r,flush=True)
pd.DataFrame(rs).to_csv(O/'08_matched_cohort_paired_bootstrap_exploratory.csv',index=False)
