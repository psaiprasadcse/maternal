"""Audits uploaded maternal dataset and notebook methodology.
Outputs preliminary matched-cohort five-fold scores and W1 Hb-removal sensitivity.
These are NEW exploratory analyses, not replacement claims about published R1 results.
"""
import os,sys,time,json,importlib.util
os.environ['OPENBLAS_NUM_THREADS']='1'; os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import pandas as pd, numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.base import clone
from sklearn.metrics import roc_auc_score,average_precision_score,brier_score_loss, fbeta_score,confusion_matrix,recall_score,precision_score
ROOT=Path(__file__).resolve().parent
out=ROOT/'Maternal_Revision_Audit_Results';out.mkdir(exist_ok=True)
sp=importlib.util.spec_from_file_location('mat_pipe', ROOT/'_maternal_pipeline_extracted.py')
m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
df=m.clean_target(m.load_dataset(str(ROOT/'maternal_dataset_csv.csv')))
specs=m.build_window_specs(df,3,'window_specific',m.WINDOWS)
# Data audit and conditional Hb associations
rows=[]
for w in m.WINDOWS:
 d=df.loc[specs[w].cohort_mask];rows.append(dict(window=w,n=len(d),high=int(d.risk.sum()),low=int((d.risk==0).sum()),high_prevalence=float(d.risk.mean()),median_missing_fraction=float(d[specs[w].all_feature_columns].isna().mean().median()),mean_missing_fraction=float(d[specs[w].all_feature_columns].isna().mean().mean())))
pd.DataFrame(rows).to_csv(out/'01_window_cohort_profile.csv',index=False)
h=df.hemoglobin_check_result_v1
rows=[]
for label,mask in [('below_12',h<12),('at_least_12',h>=12),('missing',h.isna())]:
 z=df.loc[mask];rows.append(dict(hemoglobin_v1_category=label, n=len(z), high=int(z.risk.sum()),low=int((z.risk==0).sum()),high_prevalence=float(z.risk.mean())))
pd.DataFrame(rows).to_csv(out/'02_hemoglobin_label_audit.csv',index=False)

def fit_predict(tr,va,te,columns,model=None):
 if model is None:model=m.get_models(['random_forest'])['RandomForest']
 xx=[d[columns].copy() for d in (tr,va,te)]
 builder=m.MaternalFeatureBuilder(max_missing_rate=.98,max_cardinality=30)
 Xtr=builder.fit_transform(xx[0]);Xva=builder.transform(xx[1]);Xte=builder.transform(xx[2]);
 preprocess=m.build_preprocessor(Xtr)
 a=preprocess.fit_transform(Xtr);b=preprocess.transform(Xva);c=preprocess.transform(Xte)
 cl=clone(model).fit(a,tr.risk.to_numpy())
 vp=cl.predict_proba(b)[:,1];t=m.choose_threshold(va.risk.to_numpy(),vp)
 p=cl.predict_proba(c)[:,1]
 return dict(prob=p, threshold=t, model=cl, builder=builder, preprocessor=preprocess, encoded_feature_names=m.get_feature_names(preprocess))

def scores(y,p,t):
 pred=(p>=t).astype(int);a=confusion_matrix(y,pred,labels=[0,1]).ravel()
 return dict(auroc=roc_auc_score(y,p),auprc=average_precision_score(y,p),brier=brier_score_loss(y,p),f2=fbeta_score(y,pred,beta=2),precision=precision_score(y,pred,zero_division=0),recall=recall_score(y,pred,zero_division=0),specificity=a[0]/(a[0]+a[1]),threshold=t,tn=int(a[0]),fp=int(a[1]),fn=int(a[2]),tp=int(a[3]))

# 70/15/15 split (matches original notebook) W1 Hb family ablation
w='W1';cols=list(dict.fromkeys(specs[w].all_feature_columns));z=df[cols+['risk']].copy()
tr,va,te=m.split_dataframe(z,.70,.15,.15)
ablations={
  'all_W1_predictors':cols,
  'exclude_Hb_anaemia_family':[c for c in cols if not any(t in c.lower() for t in ['hemoglobin','haemoglobin','anemia','anaemia'])],
  'exclude_Hb_BP_glucose_proteinuria':[c for c in cols if not any(t in c.lower() for t in ['hemoglobin','haemoglobin','anemia','anaemia','blood_pressure','hypertension','glucose','blood_sugar','protein_in_urine','proteinuria'])],
}
res=[]
for name,c in ablations.items():
 t0=time.time();a=fit_predict(tr,va,te,c);rr=scores(te.risk.to_numpy(),a['prob'],a['threshold']);rr.update(scenario=name,n_features_raw=len(c),n_train=len(tr),n_val=len(va),n_test=len(te));res.append(rr)
 print('ABLATION',name,{k:round(v,5) if isinstance(v,float) else v for k,v in rr.items() if k in ['auroc','auprc','brier','f2','recall','specificity','threshold']},'seconds',round(time.time()-t0,1),flush=True)
 pd.DataFrame({'sn':te.sn.values,'risk':te.risk.values,'prob':a['prob']}).to_csv(out/f'W1_predictions_{name}.csv',index=False)
pd.DataFrame(res).to_csv(out/'03_W1_feature_family_ablation.csv',index=False)

# Actual matched-cohort 5-fold comparison: same 3021 women, shared folds, RF400
anchor=df.loc[specs['W4'].cohort_mask].copy().reset_index(drop=True)
skf=StratifiedKFold(n_splits=5,shuffle=True,random_state=42)
folds=list(skf.split(anchor,anchor.risk))
cvrows=[]; oofrows=[]
for w in m.WINDOWS:
 cols=list(dict.fromkeys(specs[w].all_feature_columns))
 for fold,(it,iv) in enumerate(folds,1):
  t0=time.time();tr=anchor.iloc[it];va=anchor.iloc[iv]
  # use val for metric only: threshold fixed 0.5; AUROC/AUPRC/Brier threshold independent
  d=fit_predict(tr,va,va,cols)
  y=va.risk.to_numpy();p=d['prob']
  rr=scores(y,p,.5); rr.update(window=w,fold=fold,n_validation=len(y),prevalence=float(np.mean(y)))
  cvrows.append(rr)
  oofrows.extend(dict(window=w,fold=fold,sn=int(sn),risk=int(yy),prob=float(pp)) for sn,yy,pp in zip(va.sn,y,p))
  print('MATCHED 5FOLD',w,fold,'AUROC',round(rr['auroc'],4),'AUPRC',round(rr['auprc'],4),'seconds',round(time.time()-t0,1),flush=True)
  pd.DataFrame(cvrows).to_csv(out/'04_matched_cohort_RF_5fold_metrics.csv',index=False)
pd.DataFrame(oofrows).to_csv(out/'05_matched_cohort_oof_predictions.csv',index=False)
summary=pd.DataFrame(cvrows).groupby('window').agg(n=('n_validation','sum'),auroc_mean=('auroc','mean'),auroc_sd=('auroc','std'),auprc_mean=('auprc','mean'),auprc_sd=('auprc','std'),brier_mean=('brier','mean'),brier_sd=('brier','std'),prevalence=('prevalence','mean')).reset_index()
summary.to_csv(out/'06_matched_cohort_cv_summary.csv',index=False)
# pairwise paired fold delta, pvalues exploratory (small 5 folds)
from scipy.stats import wilcoxon
cv=pd.DataFrame(cvrows)
comparisons=[]
for aw,bw in zip(m.WINDOWS[:-1],m.WINDOWS[1:]):
 da=cv.query('window == @aw').sort_values('fold').reset_index(drop=True)
 db=cv.query('window == @bw').sort_values('fold').reset_index(drop=True)
 for metric in ('auroc','auprc','brier'):
  diff=db[metric].to_numpy()-da[metric].to_numpy()
  pval=float(wilcoxon(diff).pvalue) if (np.abs(diff)>1e-12).any() else 1.
  comparisons.append(dict(from_window=aw,to_window=bw,metric=metric,mean_difference=float(diff.mean()),sd_difference=float(diff.std(ddof=1)),wilcoxon_raw_p=pval,n_folds=5))
pd.DataFrame(comparisons).to_csv(out/'07_matched_cohort_paired_fold_differences.csv',index=False)
print('DONE',summary.to_string(index=False),flush=True)
