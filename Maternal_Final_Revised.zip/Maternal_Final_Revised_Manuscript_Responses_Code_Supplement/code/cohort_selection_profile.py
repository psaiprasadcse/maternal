from pathlib import Path
import sys,importlib.util,pandas as pd
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("mat_pipe",ROOT/"_maternal_pipeline_extracted.py")
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
df=m.clean_target(m.load_dataset(str(ROOT/"maternal_dataset_csv.csv")))
a=m.build_window_specs(df,3,"window_specific",m.WINDOWS)["W4"].cohort_mask
rows=[]
for label,d in [("Visit-4 complete",df.loc[a]),("Not visit-4 complete",df.loc[~a])]:
 bp=d.blood_pressure_v1.astype(str).str.extract(r"(\d{2,3})\s*/\s*(\d{2,3})").astype(float)
 hb=pd.to_numeric(d.hemoglobin_check_result_v1,errors="coerce")
 rows.append(dict(cohort=label,n=len(d),high_pct=round(d.risk.mean()*100,2),median_age=d.age.median(),median_pregnancies=d.no_pregnancy.median(),median_Hb1=hb.median(),median_BP1=f"{bp[0].median():.0f}/{bp[1].median():.0f}",missing_Hb1_pct=round(hb.isna().mean()*100,1),missing_BP1_pct=round(bp[0].isna().mean()*100,1)))
OUT=ROOT/"Maternal_Revision_Audit_Results";OUT.mkdir(exist_ok=True)
pd.DataFrame(rows).to_csv(OUT/"12_followup_retention_covariate_profile.csv",index=False)
print(pd.DataFrame(rows).to_string(index=False))
